AstroVax
By moop (C) 2010
v1.0

Not to be used for profit in any way or redistributed in any altered form.

http://moop.org.uk
mooped@gmail.com

Special thanks to Candice for being awesome, MrBrick for nifty ideas and the
rest of the #burrito lot for support and additional awesomeness.

A game about defending a giant space vacuum cleaner from oncoming enemies.
Hold out as long as possible to allow engineers to finish work on this
project that will save the planet from oppression (actually it will just get
you a high score, let's keep that between you and me).

The title screen should cover everything else.

Enjoy.

